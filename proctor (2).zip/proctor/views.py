# views_production.py - Enhanced with Object Violation Handling
import base64
import cv2
import numpy as np
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from django.core.cache import cache
from django.db import transaction
from .models import ExamSession, Violation, Screenshot
from .detector import ProctorDetector
import time
import threading
import json
from datetime import datetime, timedelta

# Global detector instances
detector_pool = {}
detector_lock = threading.Lock()

# Configuration
MAX_WARNINGS = 5
GRACE_PERIOD_FRAMES = 8
VIOLATION_COOLDOWN = 3

# Object violation specific settings
OBJECT_VIOLATION_COOLDOWN = 2  # Seconds between object violations
MOBILE_PHONE_COOLDOWN = 1      # 1 second cooldown for mobile phones
CORRECTION_GRACE_PERIOD = 3    # Seconds allowed to remove prohibited item

@csrf_exempt
@require_http_methods(["POST"])
def analyze_frame(request):
    try:
        # Parse request
        data = json.loads(request.body) if request.content_type == 'application/json' else request.POST
        image_data = data.get("image")
        candidate_id = data.get("candidate_id")
        
        if not image_data or not candidate_id:
            return JsonResponse({"error": "Missing data"}, status=400)
        
        # Get or create session
        # Removed select_for_update to prevent SQLite locking
        # Get or create session
        # Removed select_for_update to prevent SQLite locking
        try:
            session = ExamSession.objects.filter(candidate_id=candidate_id).first()
            if not session:
                session = ExamSession.objects.create(candidate_id=candidate_id)
            
            if session.terminated:
                return JsonResponse({
                    "terminated": True,
                    "message": "Exam terminated",
                    "violations": session.violations
                })
        except Exception as e:
            print(f"DB Error in analyze_frame: {e}")
            return JsonResponse({"error": "Database error"}, status=500)
        
        # Get detector instance
        with detector_lock:
            if candidate_id not in detector_pool:
                detector_pool[candidate_id] = ProctorDetector(device='cpu')
            detector = detector_pool[candidate_id]
        
        # Decode image
        if "," in image_data:
            image_data = image_data.split(",", 1)[1]
        
        img_bytes = base64.b64decode(image_data)
        np_arr = np.frombuffer(img_bytes, np.uint8)
        frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
        
        if frame is None:
            return JsonResponse({"error": "Invalid image"}, status=400)
        
        # Analyze frame
        result = detector.analyze_frame(frame)
        
        # Initialize response
        response = {
            "face_detected": result["face_detected"],
            "multiple_faces": result["multiple_faces"],
            "heavy_movement": result["heavy_movement"],
            "object_detected": result["object_detected"],
            "object_violation": result.get("object_violation", False),
            "violation_type": result.get("violation_type"),
            "violation_severity": result.get("violation_severity"),
            "correction_time_remaining": result.get("correction_time_remaining"),
            "face_count": result["face_count"],
            "movement_score": result["movement_score"],
            "object_details": result.get("object_details", []),
            "violation_details": result.get("violation_details", []),
            "violations": session.violations,
            "terminated": session.terminated,
            "violation_logged": False,
            "show_warning": False,
            "current_violation": None,
            "processing_time": result.get("processing_time", 0)
        }
        
        # Check for mobile phone violations (Specialized Detector)
        if result.get("mobile_phone_detected"):
            response["mobile_phone_detected"] = True
            response["mobile_phone_count"] = result["mobile_phone_count"]
            
            # Check for violation
            if result.get("object_violation") and result.get("violation_type") == "Mobile Phone":
                # Only log if it's new or not showing currently
                # The detector handles the violation readiness, we just need to log it
                
                # Check cooldown
                cooldown_key = f"violation_cooldown_{candidate_id}_mobile_phone"
                last_violation = cache.get(cooldown_key, 0)
                current_time = time.time()
                
                if current_time - last_violation > MOBILE_PHONE_COOLDOWN:
                    # Log violation
                    violation_data = result["violation_details"][-1] if result["violation_details"] else None
                    if violation_data:
                        violation = handle_violation(candidate_id, "mobile_phone", 
                                                    f"📱 Mobile Phone detected! (Visible for {violation_data.get('time_visible', 0)}s)", 
                                                    session, threshold=1)
                        if violation:
                            response.update(violation)
                            save_screenshot_async(session.id, image_data, "Mobile Phone detected")
            
            # Check for grace period warning
            elif result.get("correction_time_remaining") is not None and result.get("violation_type") is None:
                # We are in grace period (or detector just says to warn)
                # But for mobile phones we want strictness. The detector logic sets object_violation=True 
                # if priority=1 and time_visible>0.5s.
                pass

        # Check for object violations with correction grace period
        if result.get("object_violation") and result.get("violation_type") != "Mobile Phone":
            violation = handle_object_violation(
                candidate_id, 
                result["violation_details"],
                session
            )
            
            if violation:
                response["violation_logged"] = True
                response["show_warning"] = True
                response["current_violation"] = violation["current_violation"]
                response["correction_time_remaining"] = violation.get("correction_time_remaining", 0)
                
                # Check for termination info in violation result
                if violation.get("terminated"):
                    response["terminated"] = True
                    response["message"] = violation["message"]
                
                # Update session violations
                session.refresh_from_db()
                response["violations"] = session.violations
                
                # Save screenshot
                save_screenshot_async(session.id, image_data, violation.get("current_violation", "Object Violation"))
        
        # Check for other violations (no face, multiple faces, heavy movement)
        elif not result["face_detected"] and not result["multiple_faces"] and not result["mobile_phone_detected"]:
            # No face detected: Wait 2 frames to be sure (avoid blinking)
            violation = handle_violation(candidate_id, "no_face", "Face not visible", session, threshold=2)
            if violation:
                response.update(violation)
                save_screenshot_async(session.id, image_data, "Face not visible")
        
        elif result["multiple_faces"]:
            # Multiple faces: Immediate violation (threshold=1)
            violation = handle_violation(candidate_id, "multiple_faces", "Multiple persons detected", session, threshold=1)
            if violation:
                response.update(violation)
                save_screenshot_async(session.id, image_data, "Multiple persons detected")
        
        elif result["heavy_movement"]:
            # Heavy movement: Wait 2 frames
            violation = handle_violation(candidate_id, "heavy_movement", "Excessive movement detected", session, threshold=2)
            if violation:
                response.update(violation)
                save_screenshot_async(session.id, image_data, "Excessive movement detected")
        
        return JsonResponse(response)
        
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
        return JsonResponse({"error": str(e)}, status=500)


def handle_object_violation(candidate_id, violation_details, session):
    """Handle object violations with correction grace period"""
    current_time = time.time()
    violation_result = None
    
    for violation in violation_details:
        object_type = violation["type"]
        severity = violation["severity"]
        grace_remaining = violation.get("grace_remaining", 0)
        near_face = violation.get("near_face", False)
        
        # Create cache keys
        cooldown_key = f"object_cooldown_{candidate_id}_{object_type}"
        grace_key = f"grace_period_{candidate_id}_{object_type}"
        
        # Check if in grace period
        grace_start = cache.get(grace_key)
        
        if not grace_start:
            # Start grace period for correction
            cache.set(grace_key, current_time, timeout=CORRECTION_GRACE_PERIOD)
            
            violation_result = {
                "violation_logged": False,
                "show_warning": True,
                "current_violation": f"⚠️ {object_type} detected! Please remove it within {CORRECTION_GRACE_PERIOD} seconds",
                "correction_time_remaining": CORRECTION_GRACE_PERIOD,
                "grace_period_active": True
            }
            
        else:
            # Check if grace period expired
            elapsed = current_time - grace_start
            
            if elapsed >= CORRECTION_GRACE_PERIOD:
                # Grace period expired - log violation
                last_violation = cache.get(cooldown_key, 0)
                
                if current_time - last_violation > MOBILE_PHONE_COOLDOWN:
                    # Log the violation
                    # Use transaction if supported well, but for SQLite avoid complex locks
                    try:
                        # Refetch to be safe
                        session = ExamSession.objects.get(id=session.id)
                        
                        if session.violations < MAX_WARNINGS:
                            reason = f"Prohibited object: {object_type} (not removed within {CORRECTION_GRACE_PERIOD}s)"
                            Violation.objects.create(session=session, reason=reason)
                            
                            session.violations += 1
                            session.save()
                            
                            # Update cache
                            cache.set(cooldown_key, current_time, timeout=VIOLATION_COOLDOWN * 2)
                            cache.delete(grace_key)
                            
                            warning_count = session.violations
                            remaining_warnings = MAX_WARNINGS - warning_count
                            
                            violation_result = {
                                "violation_logged": True,
                                "show_warning": True,
                                "current_violation": f"🚫 VIOLATION: {object_type} detected and not removed",
                                "violations": session.violations,
                                "correction_time_remaining": 0,
                                "grace_period_active": False
                            }
                            
                            # Check for termination
                            if session.violations >= MAX_WARNINGS:
                                session.terminated = True
                                session.save()
                                
                                # Cleanup
                                with detector_lock:
                                    if candidate_id in detector_pool:
                                        del detector_pool[candidate_id]
                                
                                violation_result["terminated"] = True
                                violation_result["message"] = "Exam terminated due to excessive violations"
                    except Exception as e:
                        print(f"DB Error in handle_object_violation: {e}")
            else:
                # Still in grace period
                remaining = round(CORRECTION_GRACE_PERIOD - elapsed, 1)
                
                violation_result = {
                    "violation_logged": False,
                    "show_warning": True,
                    "current_violation": f"⚠️ {object_type} detected! Remove it in {remaining}s",
                    "correction_time_remaining": remaining,
                    "grace_period_active": True
                }
    
    return violation_result


def handle_violation(candidate_id, violation_type, message, session, threshold=2):
    """Handle standard violations"""
    current_time = time.time()
    
    # Get violation counter
    counter_key = f"violation_counter_{candidate_id}_{violation_type}"
    count = cache.get(counter_key, 0) + 1
    cache.set(counter_key, count, timeout=10)
    
    # Need consecutive frames for violation
    if count >= threshold:
        # Check cooldown
        cooldown_key = f"violation_cooldown_{candidate_id}_{violation_type}"
        last_violation = cache.get(cooldown_key, 0)
        
        if current_time - last_violation > VIOLATION_COOLDOWN:
            # Removed transaction.atomic for SQLite concurrency stability
            try:
                session = ExamSession.objects.get(id=session.id)
                
                if session.violations < MAX_WARNINGS:
                    Violation.objects.create(session=session, reason=message)
                    
                    session.violations += 1
                    session.save()
                    
                    cache.set(cooldown_key, current_time, timeout=VIOLATION_COOLDOWN)
                    cache.delete(counter_key)
                    
                    result = {
                        "violation_logged": True,
                        "show_warning": True,
                        "current_violation": f"⚠️ {message}",
                        "violations": session.violations
                    }
                    
                    if session.violations >= MAX_WARNINGS:
                        session.terminated = True
                        session.save()
                        
                        with detector_lock:
                            if candidate_id in detector_pool:
                                del detector_pool[candidate_id]
                        
                        result["terminated"] = True
                        result["message"] = "Exam terminated due to excessive violations"
                    
                    return result
            except Exception as e:
                print(f"DB Error in handle_violation: {e}")
    
    return None


def save_screenshot_async(session_id, image_data, reason):
    """Save screenshot asynchronously"""
    def _save():
        try:
            # Use get_or_create to prevent duplicates (safe for threaded)
            Screenshot.objects.get_or_create(
                session_id=session_id,
                reason=reason[:255],
                defaults={'image': image_data}
            )
        except Exception as e:
            print(f"Screenshot error: {e}")
    
    threading.Thread(target=_save, daemon=True).start()


@csrf_exempt
@require_http_methods(["POST"])
def reset_session(request):
    """Reset exam session"""
    try:
        data = json.loads(request.body) if request.content_type == 'application/json' else request.POST
        candidate_id = data.get("candidate_id")
        
        if not candidate_id:
            return JsonResponse({"error": "Missing candidate_id"}, status=400)
        
        # Delete session
        # Delete session
        ExamSession.objects.filter(candidate_id=candidate_id).delete()
        
        # Cleanup detector
        with detector_lock:
            if candidate_id in detector_pool:
                del detector_pool[candidate_id]
        
        # Clear all cache keys for this candidate
        try:
            cache.delete_pattern(f"*{candidate_id}*")
        except:
            pass
        
        return JsonResponse({"message": "Session reset successfully"})
        
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)