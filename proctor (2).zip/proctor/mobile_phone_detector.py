# mobile_phone_detector.py - Ultra Sensitive Mobile Phone Detection
import cv2
import torch
import time
from collections import defaultdict

class MobilePhoneDetector:
    def __init__(self, device='cpu'):
        self.device = device
        
        # Load YOLOv5 model
        print(f"Loading YOLOv5s for Mobile Phone Detection on {device}...")
        try:
            # Force reload to avoid cache issues
            self.model = torch.hub.load('ultralytics/yolov5', 'yolov5s', pretrained=True, verbose=False, _verbose=False)
        except Exception as e:
            print(f"Error loading YOLOv5: {e}")
            try:
                self.model = torch.hub.load('ultralytics/yolov5', 'yolov5n', pretrained=True)
            except Exception as e2:
                print(f"Critical Error loading fallback model: {e2}")
                self.model = None

        if self.model:
            # Only detect mobile phones (COCO classes 67 and 77)
            self.model.classes = [67, 77]
            self.model.conf = 0.20  # Very low threshold (Ultra Sensitive)
            self.model.iou = 0.3
            self.model.agnostic = True  # Class-agnostic NMS
            self.model.to(device)
            self.model.eval()
        
        # Tracking
        self.phone_tracker = {}
        self.grace_period = 0  # IMMEDIATE VIOLATION (Ultra Sensitive)
        self.frame_count = 0
        
    def detect_phones(self, frame):
        """
        Detect any part of mobile phone in frame (Ultra Sensitive)
        Returns: list of phone detections with all details
        """
        if self.model is None:
            return []

        results = []
        current_time = time.time()
        self.frame_count += 1
        
        try:
            # Run detection with multiple scales for better partial detection
            # Note: passing size to model() if supported, else default
            detections = self.model(frame, size=640) 
            
            for *box, conf, cls in detections.xyxy[0].cpu().numpy():
                if int(cls) in [67, 77]:
                    x1, y1, x2, y2 = map(int, box)
                    
                    # Calculate area and aspect ratio
                    width = x2 - x1
                    height = y2 - y1
                    area = width * height
                    aspect_ratio = width / height if height > 0 else 0
                    
                    # Even very small detections count (camera module, edge, corner)
                    frame_area = frame.shape[0] * frame.shape[1]
                    area_percentage = (area / frame_area) * 100
                    
                    # Ultra Sensitive: Detect even tiny parts (0.3% of frame or more)
                    if area_percentage < 0.3:
                        continue  # Too small usage, essentially noise
                    
                    # Create unique ID based on coordinates
                    phone_id = f"{x1}_{y1}_{x2}_{y2}"
                    
                    # Track phone
                    if phone_id not in self.phone_tracker:
                        self.phone_tracker[phone_id] = {
                            'first_seen': current_time,
                            'last_seen': current_time,
                            'grace_start': current_time,
                            'violation_logged': False,
                            'frames': 1,
                            'confidence_sum': float(conf),
                            'bbox': (x1, y1, width, height)
                        }
                    else:
                        self.phone_tracker[phone_id]['last_seen'] = current_time
                        self.phone_tracker[phone_id]['frames'] += 1
                        self.phone_tracker[phone_id]['confidence_sum'] += float(conf)
                        self.phone_tracker[phone_id]['bbox'] = (x1, y1, width, height)
                    
                    # Calculate times
                    time_visible = current_time - self.phone_tracker[phone_id]['first_seen']
                    
                    # Check grace period (Immedate violation in this mode)
                    violation = False
                    grace_remaining = 0
                    
                    if not self.phone_tracker[phone_id]['violation_logged']:
                         # Use grace_period = 0 for immediate
                        elapsed_grace = current_time - self.phone_tracker[phone_id]['grace_start']
                        if elapsed_grace >= self.grace_period:
                            violation = True
                            # Only log internally if we want to stop reporting it, 
                            # but usually we want to keep reporting it as long as it's there.
                            # The caller (detector.py) handles the "violation_logged" state? 
                            # self.phone_tracker[phone_id]['violation_logged'] = True 
                            # Actually detector.py handles creating specific violation objects. I will flag it here.
                    
                    # Identify part for reporting
                    phone_part = self._identify_phone_part(width, height, area_percentage)
                    
                    results.append({
                        'bbox': (x1, y1, width, height),
                        'confidence': float(conf),
                        'time_visible': round(time_visible, 1),
                        'grace_remaining': 0, # Immediate
                        'violation': violation,
                        'phone_id': phone_id,
                        'phone_part': phone_part,
                        'area_percentage': round(area_percentage, 1)
                    })
            
            # Cleanup old detections
            self._cleanup(current_time)
            
            return results

        except Exception as e:
            print(f"Mobile Phone Inference Error: {e}")
            return []

    def check_violation(self, phone_detections):
        """
        Check if any phone detection should trigger a violation
        Returns: violation info dict or None
        """
        # In Ultra Sensitive mode, ANY detection is a violation immediately
        for phone in phone_detections:
            if phone['violation']:
                 # We return the first violation found
                return {
                    'type': 'mobile_phone',
                    'message': f"📱 {phone['phone_part']} detected! Remove immediately.",
                    'confidence': phone['confidence'],
                    'time_visible': phone['time_visible'],
                    'bbox': phone['bbox'],
                    'grace_period': 0,
                    'detection_id': phone['phone_id']
                }
        return None

    def get_grace_period_status(self, phone_detections):
        """
        Get grace period status for active phone detections
        """
        # In Ultra Sensitive mode, grace period is basically 0, so this might always be empty 
        # or we return them with 0 remaining.
        active_phones = []
        for phone in phone_detections:
            if not phone['violation']: # Should rarely happen if grace is 0
                active_phones.append({
                    'grace_remaining': 0,
                    'confidence': phone['confidence'],
                    'bbox': phone['bbox']
                })
        return active_phones

    def _identify_phone_part(self, width, height, area_percentage):
        """Identify which part of phone is detected"""
        aspect_ratio = width / height if height > 0 else 0
        
        # Very small detection
        if area_percentage < 1.0:
            if width < 30 and height < 30:
                return "Camera Module/Lens"
            elif width < 50 and height < 20:
                return "Phone Edge/Corner"
            elif width < 20 and height < 50:
                return "Phone Side Edge"
            else:
                return "Small Phone Part"
        
        # Small detection
        elif area_percentage < 2.0:
            if aspect_ratio > 2.0:
                return "Top Edge of Phone"
            elif aspect_ratio < 0.5:
                return "Side Edge of Phone"
            else:
                return "Partial Phone Body"
        
        # Medium detection
        elif area_percentage < 5.0:
            if aspect_ratio > 1.8:
                return "Top Portion of Phone"
            elif aspect_ratio < 0.6:
                return "Side Portion of Phone"
            else:
                return "Partial Phone Screen"
        
        # Large detection
        else:
            if aspect_ratio > 1.6:
                return "Full Phone (Landscape)"
            elif aspect_ratio < 0.7:
                return "Full Phone (Portrait)"
            else:
                return "Mobiel Phone"

    def _cleanup(self, current_time):
        """Remove old phones"""
        to_delete = []
        for pid, info in self.phone_tracker.items():
            if current_time - info['last_seen'] > 1.0:  # Fast cleanup in sensitive mode
                to_delete.append(pid)
        
        for pid in to_delete:
            del self.phone_tracker[pid]

    def reset(self):
        """Reset detector state"""
        self.phone_tracker.clear()
        self.frame_count = 0