from django.urls import path
from .views import analyze_frame, reset_session

urlpatterns = [
    path("analyze/", analyze_frame, name="analyze_frame"),
    path("reset/", reset_session, name="reset_session"),
]