import base64
import cv2
import numpy as np
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from django.core.cache import cache
from django.db import transaction, connection
from .models import ExamSession, Violation, Screenshot
from .detector import ProctorDetector
from collections import defaultdict
import time
import threading
import json

# Global detector pool
detector_pool = {}
detector_lock = threading.Lock()

# Violation tracking (use cache for distributed systems)
VIOLATION_PREFIX = 'violations_'
LAST_VIOLATION_PREFIX = 'last_violation_'

# Configuration
MAX_WARNINGS = 5
GRACE_PERIOD_FRAMES = 8
VIOLATION_COOLDOWN = 3
CONSECUTIVE_VIOLATIONS = 2
OBJECT_VIOLATION_THRESHOLD = 1  # Single detection for objects

@csrf_exempt
@require_http_methods(["POST"])
def analyze_frame(request):
    try:
        # Parse request
        data = json.loads(request.body) if request.content_type == 'application/json' else request.POST
        image_data = data.get("image")
        candidate_id = data.get("candidate_id")
        
        if not image_data or not candidate_id:
            return JsonResponse({"error": "Missing data"}, status=400)
        
        # Get or create session
        # Removed select_for_update to prevent SQLite locking issues
        with transaction.atomic():
            session, created = ExamSession.objects.get_or_create(candidate_id=candidate_id)
            
            if session.terminated:
                return JsonResponse({
                    "terminated": True,
                    "message": "Exam terminated",
                    "violations": session.violations
                })
        
        # Get detector from pool
        with detector_lock:
            if candidate_id not in detector_pool:
                # Use CPU-only for production, YOLOv5 nano for speed
                detector_pool[candidate_id] = ProctorDetector(device='cpu', model_size='n')
            detector = detector_pool[candidate_id]
        
        # Decode image efficiently
        if "," in image_data:
            image_data = image_data.split(",", 1)[1]
        
        img_bytes = base64.b64decode(image_data)
        np_arr = np.frombuffer(img_bytes, np.uint8)
        frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
        
        if frame is None:
            return JsonResponse({"error": "Invalid image"}, status=400)
        
        # Analyze frame
        result = detector.analyze_frame(frame)
        
        # Skip if frame was skipped (performance optimization)
        # Check if detector skipped processing (e.g. frame skip)
        if result.get("frame_skipped"):
             return JsonResponse({
                "violations": session.violations,
                "terminated": session.terminated,
                "frame_skipped": True
             })
        
        # Check for violations
        violation = check_violations(candidate_id, result, detector.frame_count)
        
        violation_logged = False
        show_warning = False
        
        if violation:
            # Use transaction for database operations
            with transaction.atomic():
                # Re-fetch session to get latest state
                session = ExamSession.objects.get(candidate_id=candidate_id)
                
                if session.violations < MAX_WARNINGS:
                    # Create violation record
                    Violation.objects.create(session=session, reason=violation)
                    violation_logged = True
                    
                    # Update violation count
                    session.violations += 1
                    session.save()
                    show_warning = True
                    
                    # Save screenshot asynchronously
                    save_screenshot_async(session.id, image_data, violation)
                    
                    # Check if terminated
                    if session.violations >= MAX_WARNINGS:
                        session.terminated = True
                        session.save()
                        
                        # Cleanup
                        with detector_lock:
                            if candidate_id in detector_pool:
                                del detector_pool[candidate_id]
                        
                        result["terminated"] = True
                        result["message"] = "Exam terminated"
        
        # Prepare response
        response = {
            "face_detected": result.get("face_detected", False),
            "multiple_faces": result.get("multiple_faces", False),
            "heavy_movement": result.get("heavy_movement", False),
            "object_detected": result.get("object_detected", False),
            "face_count": result.get("face_count", 0),
            "movement_score": result.get("movement_score", 0),
            "object_details": result.get("object_details", []),
            "violations": session.violations,
            "terminated": session.terminated,
            "violation_logged": violation_logged,
            "show_warning": show_warning,
            "current_violation": violation if show_warning else None,
            "processing_time": result.get("processing_time", 0)
        }
        
        return JsonResponse(response)
        
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
        # Return actual error for debugging
        return JsonResponse({"error": str(e)}, status=500)

def check_violations(candidate_id, result, frame_count):
    """Check for violations with rate limiting"""
    if frame_count < GRACE_PERIOD_FRAMES:
        return None
    
    # Determine violation type
    violation_type = None
    violation_message = None
    
    if not result["face_detected"] and not result["multiple_faces"]:
        violation_type = "no_face"
        violation_message = "Face not visible"
    elif result["multiple_faces"]:
        violation_type = "multiple_faces"
        violation_message = "Multiple persons detected"
    elif result["object_detected"] and result["object_details"]:
        # Check if object is near face (higher priority)
        near_face_objects = [obj for obj in result["object_details"] if obj.get("near_face")]
        if near_face_objects:
            violation_type = "object_near_face"
            violation_message = f"Prohibited object near face: {near_face_objects[0]['type']}"
        else:
            violation_type = "object_detected"
            violation_message = f"Prohibited object: {result['object_details'][0]['type']}"
    elif result["heavy_movement"]:
        violation_type = "heavy_movement"
        violation_message = "Excessive movement detected"
    
    if not violation_type:
        # Reset counters for this candidate
        cache.delete(f"{VIOLATION_PREFIX}{candidate_id}")
        return None
    
    # Get violation counter from cache
    counter_key = f"{VIOLATION_PREFIX}{candidate_id}_{violation_type}"
    count = cache.get(counter_key, 0) + 1
    cache.set(counter_key, count, timeout=10)  # 10 second expiry
    
    # Check if threshold reached
    threshold = OBJECT_VIOLATION_THRESHOLD if 'object' in violation_type else CONSECUTIVE_VIOLATIONS
    
    if count >= threshold:
        # Check cooldown
        last_key = f"{LAST_VIOLATION_PREFIX}{candidate_id}_{violation_type}"
        last_time = cache.get(last_key, 0)
        current_time = time.time()
        
        if current_time - last_time > VIOLATION_COOLDOWN:
            cache.set(last_key, current_time, timeout=60)
            cache.delete(counter_key)  # Reset counter
            return violation_message
    
    return None

def save_screenshot_async(session_id, image_data, reason):
    """Save screenshot asynchronously"""
    def _save():
        try:
            # Use get_or_create to prevent duplicates
            Screenshot.objects.get_or_create(
                session_id=session_id,
                reason=reason,
                defaults={'image': image_data}
            )
        except Exception as e:
            print(f"Screenshot error: {e}")
    
    # Execute in separate thread
    threading.Thread(target=_save, daemon=True).start()

@csrf_exempt
@require_http_methods(["POST"])
def reset_session(request):
    try:
        data = json.loads(request.body) if request.content_type == 'application/json' else request.POST
        candidate_id = data.get("candidate_id")
        
        if not candidate_id:
            return JsonResponse({"error": "Missing candidate_id"}, status=400)
        
        # Delete session
        with transaction.atomic():
            ExamSession.objects.filter(candidate_id=candidate_id).delete()
        
        # Cleanup detector
        with detector_lock:
            if candidate_id in detector_pool:
                del detector_pool[candidate_id]
        
        # Clear cache
        try:
            cache.delete_pattern(f"*{candidate_id}*")
        except:
            pass # Cache backend might not support pattern deletion
        
        return JsonResponse({"message": "Session reset"})
        
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)