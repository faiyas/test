import cv2
import numpy as np
import torch
import threading
from collections import deque
import time
import os

class ProctorDetector:
    def __init__(self, device='cpu', model_size='n'):  # n=nano, s=small, m=medium
        self.device = device
        self.frame_count = 0
        self.stable_frames_required = 5
        
        # Load YOLOv5 for object detection (lightweight)
        print(f"Loading YOLOv5{model_size} on {device}...")
        try:
            # Force reload to avoid cache issues
            self.object_model = torch.hub.load('ultralytics/yolov5', f'yolov5{model_size}', 
                                            pretrained=True, verbose=False, _verbose=False)
            self.object_model.conf = 0.45  # Confidence threshold
            self.object_model.iou = 0.45   # NMS IoU threshold
            self.object_model.classes = [0, 67, 73, 77]  # person, cell phone, laptop, book
            self.object_model.to(device)
            self.object_model.eval()
        except Exception as e:
            print(f"Error loading YOLOv5: {e}")
            print("To fix: pip install pandas requests seaborn tqdm")
            self.object_model = None

        # Load face detection model (OpenCV DNN with ResNet10)
        # Ensure model files exist or fallback to Haar (not implemented in user request, but safer)
        # Using paths relative to manage.py or absolute if needed
        model_file = 'res10_300x300_ssd_iter_140000.caffemodel'
        config_file = 'deploy.prototxt'
        
        if os.path.exists(model_file) and os.path.exists(config_file):
            print("Loading FaceNet (Caffe)...")
            self.face_net = cv2.dnn.readNetFromCaffe(config_file, model_file)
            self.use_dnn_face = True
        else:
            print("Warning: Caffe model files not found. Face detection will fail.")
            self.use_dnn_face = False
            self.face_net = None # Could fallback to Haar here if desired
        
        # Movement detection
        self.prev_gray = None
        self.movement_history = deque(maxlen=10)
        
        # Performance optimization
        self.frame_skip = 2  # Process every 2nd frame
        self.resize_dim = (320, 240)  # Resize for faster processing
        
        # Cache for face detections
        self.face_cache = []
        self.cache_timer = 0
        
        # Prohibited items (COCO classes)
        self.prohibited_items = {
            67: 'Mobile Phone',
            73: 'Laptop/Tablet', 
            77: 'Book/Notes',
            62: 'TV/Monitor',
            72: 'TV/Monitor',
            64: 'Remote',
            66: 'Keyboard',
            74: 'Mouse',
            84: 'Book'
        }
        
    def analyze_frame(self, frame):
        result = {
            "face_detected": False,
            "multiple_faces": False,
            "heavy_movement": False,
            "object_detected": False,
            "face_count": 0,
            "movement_score": 0,
            "object_details": [],
            "processing_time": 0,
            "frame_skipped": False
        }
        
        start_time = time.time()
        
        # Skip frames for performance
        self.frame_count += 1
        if self.frame_count % self.frame_skip != 0:
            result["frame_skipped"] = True
            return result
        
        # Resize frame for faster processing
        small_frame = cv2.resize(frame, self.resize_dim)
        h, w = small_frame.shape[:2]
        
        # ---------------- FAST FACE DETECTION (OpenCV DNN) ----------------
        faces = []
        
        if self.use_dnn_face and self.face_net:
            try:
                # SSD model expects 300x300 input
                blob = cv2.dnn.blobFromImage(small_frame, 1.0, (300, 300), 
                                            [104, 117, 123], False, False)
                self.face_net.setInput(blob)
                detections = self.face_net.forward()
                
                for i in range(detections.shape[2]):
                    confidence = detections[0, 0, i, 2]
                    if confidence > 0.6:  # Slightly lower confidence threshold
                        box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
                        x1, y1, x2, y2 = box.astype(int)
                        
                        # Scale back to original frame size
                        scale_x = frame.shape[1] / self.resize_dim[0]
                        scale_y = frame.shape[0] / self.resize_dim[1]
                        
                        x1 = int(x1 * scale_x)
                        y1 = int(y1 * scale_y)
                        x2 = int(x2 * scale_x)
                        y2 = int(y2 * scale_y)
                        
                        # Ensure coordinates are within frame
                        x1 = max(0, x1)
                        y1 = max(0, y1)
                        x2 = min(frame.shape[1], x2)
                        y2 = min(frame.shape[0], y2)
                        
                        if x2 > x1 and y2 > y1:
                            faces.append((x1, y1, x2 - x1, y2 - y1))
            except Exception as e:
                print(f"Face Detection Error: {e}")
                import traceback
                traceback.print_exc()
        
        result["face_count"] = len(faces)
        
        # Face detection logic
        if len(faces) == 1:
            result["face_detected"] = True
            result["multiple_faces"] = False
        elif len(faces) > 1:
            if self._are_faces_overlapping(faces):
                result["face_detected"] = True
                result["multiple_faces"] = False
            else:
                result["face_detected"] = False
                result["multiple_faces"] = True
        else:
            result["face_detected"] = False
            result["multiple_faces"] = False
        
        # ---------------- FAST MOVEMENT DETECTION ----------------
        gray = cv2.cvtColor(small_frame, cv2.COLOR_BGR2GRAY)
        gray = cv2.GaussianBlur(gray, (5, 5), 0)
        
        if self.prev_gray is not None and self.frame_count > self.stable_frames_required:
            diff = cv2.absdiff(self.prev_gray, gray)
            _, thresh = cv2.threshold(diff, 25, 255, cv2.THRESH_BINARY)
            
            movement_percentage = (np.count_nonzero(thresh) / thresh.size) * 100
            result["movement_score"] = float(round(movement_percentage, 2))
            
            self.movement_history.append(movement_percentage)
            
            # Adaptive threshold based on recent movement
            if len(self.movement_history) > 5:
                avg_movement = np.mean(self.movement_history)
                threshold = max(30, avg_movement * 1.5)
                # Ensure threshold isn't too low or too high
                threshold = max(10, min(80, threshold))
                result["heavy_movement"] = bool(movement_percentage > threshold)
        
        self.prev_gray = gray.copy()
        
        # ---------------- YOLO OBJECT DETECTION ----------------
        if self.object_model and self.frame_count > self.stable_frames_required:
            try:
                # Detect prohibited items
                # YOLOv5 accepts BGR images directly (OpenCV format)
                results = self.object_model(frame)
                
                objects = []
                for *box, conf, cls in results.xyxy[0].cpu().numpy():
                    cls_id = int(cls)
                    if cls_id in self.prohibited_items and conf > 0.5:
                        x1, y1, x2, y2 = map(int, box)
                        
                        # Check if object is near face (potential cheating)
                        near_face = self._is_near_face((x1, y1, x2-x1, y2-y1), faces)
                        
                        objects.append({
                            "type": self.prohibited_items[cls_id],
                            "confidence": round(float(conf), 2),
                            "bbox": (x1, y1, x2-x1, y2-y1),
                            "near_face": bool(near_face)
                        })
                
                if objects:
                    result["object_detected"] = True
                    result["object_details"] = objects
            except Exception as e:
                print(f"YOLO Inference Error: {e}")
        
        result["processing_time"] = round((time.time() - start_time) * 1000, 2)
        
        return result
    
    def _is_near_face(self, obj_bbox, faces):
        """Check if object is near any detected face"""
        ox, oy, ow, oh = obj_bbox
        obj_center = (ox + ow//2, oy + oh//2)
        
        for (fx, fy, fw, fh) in faces:
            face_center = (fx + fw//2, fy + fh//2)
            distance = np.sqrt((obj_center[0] - face_center[0])**2 + 
                              (obj_center[1] - face_center[1])**2)
            
            # Object is near face if within 1.5x face width
            if distance < fw * 1.5:
                return True
        return False
    
    def _are_faces_overlapping(self, faces):
        """Check if faces overlap significantly"""
        if len(faces) <= 1:
            return False
        
        for i in range(len(faces)):
            for j in range(i + 1, len(faces)):
                x1, y1, w1, h1 = faces[i]
                x2, y2, w2, h2 = faces[j]
                
                # Calculate IoU
                x_left = max(x1, x2)
                y_top = max(y1, y2)
                x_right = min(x1 + w1, x2 + w2)
                y_bottom = min(y1 + h1, y2 + h2)
                
                if x_right < x_left or y_bottom < y_top:
                    continue
                
                intersection = (x_right - x_left) * (y_bottom - y_top)
                area1 = w1 * h1
                area2 = w2 * h2
                smaller = min(area1, area2)
                
                if intersection > 0.4 * smaller:
                    return True
        
        return False
    
    def reset(self):
        self.prev_gray = None
        self.frame_count = 0
        self.movement_history.clear()