from django.db import models

class ExamSession(models.Model):
    candidate_id = models.CharField(max_length=100, db_index=True, unique=True)
    violations = models.IntegerField(default=0)
    terminated = models.BooleanField(default=False, db_index=True)
    started_at = models.DateTimeField(auto_now_add=True, db_index=True)
    
    class Meta:
        indexes = [
            models.Index(fields=['candidate_id', 'terminated']),
        ]
    
    def __str__(self):
        return f"Session {self.candidate_id}"

class Violation(models.Model):
    session = models.ForeignKey(ExamSession, on_delete=models.CASCADE, db_index=True)
    reason = models.CharField(max_length=255)
    timestamp = models.DateTimeField(auto_now_add=True, db_index=True)
    
    class Meta:
        indexes = [
            models.Index(fields=['session', 'timestamp']),
        ]
    
    def __str__(self):
        return f"{self.reason} at {self.timestamp}"

class Screenshot(models.Model):
    session = models.ForeignKey(ExamSession, on_delete=models.CASCADE, db_index=True)
    image = models.TextField()
    reason = models.CharField(max_length=255)
    captured_at = models.DateTimeField(auto_now_add=True, db_index=True)
    
    class Meta:
        indexes = [
            models.Index(fields=['session', '-captured_at']),
        ]
    
    def __str__(self):
        return f"Screenshot: {self.reason}"
